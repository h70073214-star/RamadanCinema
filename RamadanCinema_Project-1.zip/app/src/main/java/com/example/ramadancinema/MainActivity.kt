package com.example.ramadancinema

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.compose.material3.Player

data class Show(
    val year: Int,
    val title: String,
    val description: String = "",
    val episodes: Int = 30
)

private val catalog = listOf(
    Show(2024, "المداح ج4: أسطورة العودة", "الفصل الرابع من سلسلة المداح."),
    Show(2024, "الحشاشين", "دراما تاريخية."),
    Show(2024, "إمبراطورية م", "دراما اجتماعية."),
    Show(2024, "نعمة الأفوكاتو", "دراما اجتماعية."),
    Show(2024, "مسار إجباري", "دراما وتشويق."),
    Show(2024, "بيت الرفاعي", "دراما وتشويق."),
    Show(2024, "العتاولة", "تشويق وإثارة."),
    Show(2024, "صدفة", "دراما اجتماعية."),
    Show(2024, "بدون سابق إنذار", "دراما وتشويق."),
    Show(2024, "المعلم", "دراما اجتماعية."),
    Show(2024, "عتبات البهجة", "دراما اجتماعية."),
    Show(2024, "خالد نور وولده نور خالد", "كوميديا."),
    Show(2024, "بابا جه", "كوميديا اجتماعية."),
    Show(2024, "صيد العقارب", "دراما وتشويق."),
    Show(2024, "حق عرب", "دراما وتشويق."),
    Show(2024, "صلة رحم", "دراما وتشويق."),
    Show(2024, "كامل العدد +1", "دراما اجتماعية."),
    Show(2024, "تل الراهب", "دراما."),
    Show(2024, "لانش بوكس", "كوميديا ودراما."),
    Show(2024, "جودر - ألف ليلة وليلة", "فانتازيا ودراما."),
    Show(2024, "سر إلهي", "تشويق وإثارة."),
    Show(2025, "سيد الناس", "دراما وتشويق."),
    Show(2025, "إش إش", "دراما اجتماعية."),
    Show(2025, "فهد البطل", "دراما وتشويق."),
    Show(2025, "حكيم باشا", "دراما صعيدية."),
    Show(2025, "وتقابل حبيب", "دراما رومانسية."),
    Show(2025, "تحت سابع أرض", "دراما وتشويق."),
    Show(2025, "السبع", "دراما."),
    Show(2025, "ليالي روكسي", "دراما."),
    Show(2025, "جريمة منتصف الليل", "غموض وتشويق."),
    Show(2025, "أسود باهت", "غموض وجريمة."),
    Show(2025, "بيت حمولة", "دراما اجتماعية."),
    Show(2025, "أبو البنات", "دراما اجتماعية.")
)

@Composable
fun App() {
    var selectedYear by remember { mutableIntStateOf(2025) }
    var selectedShow by remember { mutableStateOf<Show?>(null) }
    var search by remember { mutableStateOf("") }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFFE6B566),
            background = Color(0xFF101010),
            surface = Color(0xFF181818)
        )
    ) {
        if (selectedShow == null) {
            Scaffold(
                topBar = {
                    Column(Modifier.background(Color(0xFF101010)).padding(16.dp)) {
                        Text("رمضان سينما", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("ابحث عن مسلسل...") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            singleLine = true
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(
                                selected = selectedYear == 2025,
                                onClick = { selectedYear = 2025 },
                                label = { Text("رمضان 2025") }
                            )
                            FilterChip(
                                selected = selectedYear == 2024,
                                onClick = { selectedYear = 2024 },
                                label = { Text("رمضان 2024") }
                            )
                        }
                    }
                }
            ) { pad ->
                val list = catalog.filter {
                    it.year == selectedYear &&
                    it.title.contains(search.trim(), ignoreCase = true)
                }
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(pad),
                    contentPadding = PaddingValues(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(list) { show ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { selectedShow = show },
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1C1C1C))
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(show.title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.height(5.dp))
                                    Text("${show.year} • ${show.description}")
                                }
                                Icon(Icons.Default.PlayArrow, null)
                            }
                        }
                    }
                }
            }
        } else {
            ShowDetails(
                show = selectedShow!!,
                onBack = { selectedShow = null }
            )
        }
    }
}

@Composable
fun ShowDetails(show: Show, onBack: () -> Unit) {
    var episode by remember { mutableIntStateOf(1) }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(show.title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.fillMaxSize().padding(pad).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(show.description, fontSize = 17.sp)
            Text("الحلقات", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                items((1..show.episodes).toList()) { ep ->
                    Button(
                        onClick = { episode = ep },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("الحلقة $ep")
                    }
                }
            }
            Text(
                "ملاحظة: روابط الحلقات التجارية غير مضافة. ضع رابط فيديو تملك حق بثه في VideoRepository.kt.",
                fontSize = 13.sp
            )
            VideoPlayer(videoUrl = VideoRepository.demoUrl)
        }
    }
}

@Composable
fun VideoPlayer(videoUrl: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUrl))
            prepare()
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    Box(Modifier.fillMaxWidth().height(220.dp)) {
        Player(player = player)
    }
}

object VideoRepository {
    // Public sample video used only to verify that the player works.
    const val demoUrl =
        "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}
